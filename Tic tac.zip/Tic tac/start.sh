#!/bin/bash
echo "Starting Tic Tac Toe Game Server..."
echo ""
echo "Server will be available at: http://localhost:3000"
echo "Press Ctrl+C to stop the server"
echo ""
npm start
